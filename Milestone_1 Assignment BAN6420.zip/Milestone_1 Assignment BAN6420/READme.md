# Policy Management System at Insurance Company

This is a Python program for managing policyholders, products, and payments within an insurance company.

## Getting Started

Follow these instructions to get a copy of the project up and running on your desired machine.

- Jupyter Notebook 
- python

The project has of several .ipynb folders

- `policyholders_class.ipynb`: Contains the `Policyholder` class for managing policyholders.
- `payment_class.ipynb`: Contains the `Product` class for managing products.
- `products_class.ipynb`: Contains the `Payment` class for managing payments.
- policy_demonstration.ipynb`: Contains the main script to demonstrate the functionality of the classes.

### Instructions

1. Create instances of `Policyholder` class using the `name`, `policy_number`, and `status` (optional) parameters.
2. Create instances of `Product` class using the `name` and `price` parameters.
3. Create instances of `Payment` class using a `policyholder` object, the name of the product, and the payment amount.
4. Use the methods provided by each class (`register`, `suspend`, `reactivate` for `Policyholder`; `create_product`, `update_product`, `remove_product`, `suspend_product`, `display_products` for `Product`; `process_payment`, `send_reminder`, `apply_penalty` for `Payment`) to perform various tasks.

### Example

```python
import uuid
from datetime import datetime, timedelta


# Creating instances of Policyholder and ProductManagement classes
policyholderA = Policyholder("Comfort Akpan", "POL0001k")
policyholderB = Policyholder("Etimbuk Bassey", "POL0001k")
 
# Creating payments
paymentA = Payment(policyholderA, "Accident Insurance", 5000)
paymentB = Payment(policyholderB, "Home Insurance", 7000)


# Create an instance of the Product class
product_manager = Product()

# Create products
product_manager.create_product("Accident Insurance", 5000)
product_manager.create_product("Home Insurance", 70000)

print("\n")

# Update a product
product_manager.update_product("Accident Insurance updated to 5000.)

print("\n")

# Display products
product_manager.display_details()


Author Etimbuk Bassey as a policy management at insurance company